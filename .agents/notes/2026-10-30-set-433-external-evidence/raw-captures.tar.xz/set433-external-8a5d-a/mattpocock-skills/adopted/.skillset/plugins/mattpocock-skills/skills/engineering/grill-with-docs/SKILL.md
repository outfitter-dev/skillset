---
skillset:
  origin:
    path: skills/engineering/grill-with-docs/SKILL.md
name: grill-with-docs
description: A relentless interview to sharpen a plan or design, which also creates docs (ADR's and glossary) as we go.
claude:
  frontmatter:
    disable-model-invocation: true
---

Run a `/grilling` session, using the `/domain-modeling` skill.
