---
skillset:
  origin:
    path: skills/productivity/grill-me/SKILL.md
name: grill-me
description: A relentless interview to sharpen a plan or design.
claude:
  frontmatter:
    disable-model-invocation: true
---

Run a `/grilling` session.
