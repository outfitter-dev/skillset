---
description: A relentless interview to sharpen a plan or design, which also creates docs (ADR's and glossary) as we go.
disable-model-invocation: true
metadata:
  skillset.schema: "1"
  version: 0.1.0
name: grill-with-docs
---

Run a `/grilling` session, using the `/domain-modeling` skill.
