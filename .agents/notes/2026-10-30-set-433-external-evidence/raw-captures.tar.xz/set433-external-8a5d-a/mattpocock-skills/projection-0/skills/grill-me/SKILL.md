---
description: A relentless interview to sharpen a plan or design.
disable-model-invocation: true
metadata:
  skillset.schema: "1"
  version: 0.1.0
name: grill-me
---

Run a `/grilling` session.
