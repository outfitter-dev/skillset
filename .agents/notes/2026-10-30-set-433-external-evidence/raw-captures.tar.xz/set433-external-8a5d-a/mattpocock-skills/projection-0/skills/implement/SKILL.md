---
description: Implement a piece of work based on a PRD or set of issues.
disable-model-invocation: true
metadata:
  skillset.schema: "1"
  version: 0.1.0
name: implement
---

Implement the work described by the user in the PRD or issues.

Use /tdd where possible, at pre-agreed seams.

Run typechecking regularly, single test files regularly, and the full test suite once at the end.

Once done, use /review to review the work.

Commit your work to the current branch.
