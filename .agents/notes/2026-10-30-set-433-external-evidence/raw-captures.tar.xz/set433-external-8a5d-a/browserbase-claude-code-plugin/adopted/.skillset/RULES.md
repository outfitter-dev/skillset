---
cursor: false
---

# browserbase-claude-code-plugin

Add rules here.
