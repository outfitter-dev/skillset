---
cursor: false
---

# cursor-browser-motion-plugin

Add rules here.
