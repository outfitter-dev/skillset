import { mkdir } from "node:fs/promises";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { chromium, type Browser, type Page } from "playwright";

const __dirname = dirname(fileURLToPath(import.meta.url));

const DEFAULT_VIEWPORT = { width: 1280, height: 720 };
const MIN_FOCUS_DIM = 80;
const MAX_FOCUS_DIM = 1920;
const DEFAULT_ELEMENT_PADDING = 8;

export function getArtifactsRoot(): string {
  return join(__dirname, "..", "artifacts");
}

export type FocusMode = "viewport" | "region" | "element";

export type RecordBrowserClipOptions = {
  url: string;
  durationSeconds: number;
  viewport?: { width: number; height: number };
  headless?: boolean;
  /** What to frame in the recording. Default: full browser viewport. */
  focusMode?: FocusMode;
  /** Page coordinates (document space). Required when focusMode is `region`. */
  region?: { x: number; y: number; width: number; height: number };
  /** CSS selector; required when focusMode is `element`. */
  selector?: string;
  /** Extra pixels around the element box when focusMode is `element`. Default 8. */
  elementPadding?: number;
};

type NormalizedRegion = { x: number; y: number; width: number; height: number };

function assertHttpUrl(raw: string): URL {
  let u: URL;
  try {
    u = new URL(raw);
  } catch {
    throw new Error(`Invalid URL: ${raw}`);
  }
  if (u.protocol !== "http:" && u.protocol !== "https:") {
    throw new Error(
      "Only http:// and https:// URLs are allowed (file:// and other schemes are rejected).",
    );
  }
  return u;
}

function clampDurationSeconds(n: number): number {
  if (!Number.isFinite(n)) {
    throw new Error("durationSeconds must be a finite number.");
  }
  return Math.min(10, Math.max(1, n));
}

function clampDimension(n: number): number {
  const v = Math.floor(Math.abs(n));
  return Math.min(MAX_FOCUS_DIM, Math.max(MIN_FOCUS_DIM, v));
}

function normalizeFocusMode(raw: string | undefined): FocusMode {
  if (raw === undefined || raw === "viewport") return "viewport";
  if (raw === "region" || raw === "element") return raw;
  throw new Error(`focusMode must be "viewport", "region", or "element" (got ${JSON.stringify(raw)}).`);
}

async function elementRegionInPageSpace(
  page: Page,
  selector: string,
  padding: number,
): Promise<NormalizedRegion> {
  const box = await page.evaluate((sel) => {
    const el = document.querySelector(sel);
    if (!el || !(el instanceof Element)) return null;
    const r = el.getBoundingClientRect();
    return {
      x: r.left + window.scrollX,
      y: r.top + window.scrollY,
      width: r.width,
      height: r.height,
    };
  }, selector);

  if (!box || box.width <= 0 || box.height <= 0) {
    throw new Error(
      `No visible element found for selector, or size is zero: ${JSON.stringify(selector)}`,
    );
  }

  const p = Math.max(0, padding);
  const x = Math.max(0, Math.floor(box.x - p));
  const y = Math.max(0, Math.floor(box.y - p));
  const width = clampDimension(box.width + 2 * p);
  const height = clampDimension(box.height + 2 * p);
  return { x, y, width, height };
}

function normalizeRegionInput(r: {
  x: number;
  y: number;
  width: number;
  height: number;
}): NormalizedRegion {
  if (
    !Number.isFinite(r.x) ||
    !Number.isFinite(r.y) ||
    !Number.isFinite(r.width) ||
    !Number.isFinite(r.height)
  ) {
    throw new Error("region x, y, width, and height must be finite numbers.");
  }
  if (r.width <= 0 || r.height <= 0) {
    throw new Error("region width and height must be positive.");
  }
  return {
    x: Math.max(0, Math.floor(r.x)),
    y: Math.max(0, Math.floor(r.y)),
    width: clampDimension(r.width),
    height: clampDimension(r.height),
  };
}

/** Scroll and resize viewport so the recording shows the given document region. */
async function applyRegionFocus(page: Page, region: NormalizedRegion): Promise<void> {
  await page.evaluate(({ x, y }) => window.scrollTo(x, y), {
    x: region.x,
    y: region.y,
  });
  await page.setViewportSize({
    width: region.width,
    height: region.height,
  });
  await page.evaluate(({ x, y }) => window.scrollTo(x, y), {
    x: region.x,
    y: region.y,
  });
}

/** Records a WebM under server/artifacts; returns absolute path to the file. */
export async function recordBrowserClip(
  options: RecordBrowserClipOptions,
): Promise<{ videoPath: string; durationSeconds: number }> {
  const target = assertHttpUrl(options.url);
  const durationSeconds = clampDurationSeconds(options.durationSeconds);
  const focusMode = normalizeFocusMode(options.focusMode);

  if (focusMode === "region" && !options.region) {
    throw new Error('focusMode "region" requires a "region" object: { x, y, width, height } in page coordinates.');
  }
  if (focusMode === "element" && (!options.selector || options.selector.trim() === "")) {
    throw new Error('focusMode "element" requires a non-empty CSS "selector".');
  }
  const headless = options.headless ?? true;

  let initialW = options.viewport?.width ?? DEFAULT_VIEWPORT.width;
  let initialH = options.viewport?.height ?? DEFAULT_VIEWPORT.height;
  if (!Number.isFinite(initialW) || initialW <= 0 || !Number.isFinite(initialH) || initialH <= 0) {
    throw new Error("viewport width and height must be positive numbers.");
  }
  initialW = Math.floor(initialW);
  initialH = Math.floor(initialH);

  const sessionDir = join(
    getArtifactsRoot(),
    `clip-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
  );
  await mkdir(sessionDir, { recursive: true });

  let browser: Browser | undefined;
  try {
    browser = await chromium.launch({ headless });
    const context = await browser.newContext({
      viewport: { width: initialW, height: initialH },
      recordVideo: { dir: sessionDir },
    });
    const page = await context.newPage();
    await page.goto(target.href, { waitUntil: "load", timeout: 60_000 });

    if (focusMode === "region") {
      const region = normalizeRegionInput(options.region!);
      await applyRegionFocus(page, region);
    } else if (focusMode === "element") {
      const pad =
        options.elementPadding !== undefined
          ? Math.max(0, options.elementPadding)
          : DEFAULT_ELEMENT_PADDING;
      const loc = page.locator(options.selector!.trim()).first();
      await loc.waitFor({ state: "visible", timeout: 15_000 });
      await loc.scrollIntoViewIfNeeded();
      const region = await elementRegionInPageSpace(page, options.selector!.trim(), pad);
      await applyRegionFocus(page, region);
    }

    await new Promise((r) => setTimeout(r, Math.round(durationSeconds * 1000)));
    const video = page.video();
    await context.close();
    await browser.close();
    browser = undefined;

    if (!video) {
      throw new Error("Playwright did not attach a video recorder to the page.");
    }
    const videoPath = await video.path();
    return { videoPath, durationSeconds };
  } catch (err) {
    if (browser) {
      await browser.close().catch(() => {});
    }
    const msg = err instanceof Error ? err.message : String(err);
    if (/Executable doesn't exist|browserType\.launch|chromium/i.test(msg)) {
      throw new Error(
        `${msg}\n\nIf Chromium is missing, run once from the server folder: npx playwright install chromium`,
      );
    }
    throw err;
  }
}
