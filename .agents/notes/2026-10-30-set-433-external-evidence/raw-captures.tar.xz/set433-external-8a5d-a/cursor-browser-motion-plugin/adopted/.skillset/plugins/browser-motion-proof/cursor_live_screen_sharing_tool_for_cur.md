# Live screen sharing tool for Cursor
_Exported on 4/13/2026 at 11:41:48 PDT from Cursor (3.0.16)_

---

**User**

Okay. Any way we can create some kind of tool that you can use here in cursor so that you can see video or some type of Live. bead of the Screen. some kind of live feed Where You can see what we're working on on the browser. so that you can see animations or anything that you need to see such as like the side scrolling text and make sure everything works properly instead of just seeing snapshots. I'm wondering if there's a way we can make that happen whether creating a tool or a plug-in or something. I was just wondering if that's something we can make happen since it's not something that's already built into Cursor.

---

**Cursor**

Here’s a straight answer: **Cursor doesn’t ship a “live desktop/video stream to the model” the way you’d watch a monitor in real time**, and that’s mostly because assistants are built around **discrete inputs** (text, occasional images/video segments), not a continuous video pipe.

## What you can do today (closest to “live”)

1. **Browser MCP in Cursor**  
   The built-in browser integration is built around **snapshots + screenshots** (and interactions). That’s intentional: each step gives the model a **fresh still frame** (plus structure), not a 30fps stream. You can still **drive the app and refresh** after animations (wait → snapshot/screenshot) to verify motion *effects* as a series of frames.

2. **Short recordings you attach**  
   Some agent flows support **uploading a short screen recording** (e.g. mp4/webm) so a vision-capable model can review motion in one go. That’s “record then review,” not a perpetual live feed.

3. **Automated video from tests**  
   **Playwright** can record video or traces of runs. That’s great for **regressions** (scroll, marquee, transitions) without you manually filming.

## Could you “build a tool” for a live feed?

**Partially, with tradeoffs:**

| Approach | What it gives you | Caveats |
|----------|-------------------|---------|
| **MCP server + periodic screenshots** | Feels “live-ish” if it grabs a frame every N ms while you work | Still **frames**, not true video; rate limits, cost, and noise add up fast |
| **MCP + desktop capture** | Same idea from the whole screen or a window | Heavy; privacy; needs local code + careful scoping |
| **“Burst” mode after an action** | e.g. capture 5 frames over 2s after click | Often **better than streaming** for checking animations |

So yes, you *could* implement a **local MCP tool** that captures frames on an interval or on events, but it would still be **sampling**, not a continuous live broadcast—and the model would still reason over **individual frames** (or a short clip), which is how these systems are designed.

## Practical recommendation for your use case (scrolling text, motion)

- **Prefer**: scripted checks (Playwright: `expect` on final state, scroll position, CSS animation end, or pixel/visual comparison if you go that far).  
- **Prefer for “does it look right?”**: **short screen recording** or **a few timed screenshots** after the animation.  
- **Avoid expecting**: infinite live mirroring of your screen into the chat as a first-class feature—it’s not how the product or models are optimized to work.

If you want to go further, the most maintainable “custom” path is usually: **a small MCP server** that your repo documents, which exposes something like `capture_browser_frame` / `capture_after_delay` / `playwright_record_clip` rather than a raw endless stream.

**Bottom line:** There isn’t a hidden Cursor toggle for a live video feed; the realistic options are **frequent captures, short recordings, or test automation**—and a custom MCP can automate the first two within those constraints.

---

**User**

Thank you. I'm not asking for a continuous video pipe. I'm just saying for situations like when you're doing a browser proof run. And you want to check something, but a snapshot is not going to be suffice you would need A video. of some sort or live Motion. shot of it so that you can see what's going on instead of a snapshot. That's what I'm saying. It needs to be just for anywhere between One second to 10 seconds maybe. or something like that. I was just wondering if that's something we can make happen so that We can have the agents see uh, moving picture instead of just snapshots when they need to see something to confirm something or to be able to validate something. I'm just wondering if we can make that a possibility. It does not have to be a long process. uh, Video feed.

---

**Cursor**

Checking whether the project's browser MCP exposes recording or similar capabilities.



Yes — **a short clip (about 1–10 seconds) is a reasonable target**, and it’s a much better fit than a continuous feed. You’re basically asking for **motion samples**, not streaming.

## Is it possible?

**Yes, in a few concrete ways:**

1. **Playwright video (fits “browser proof run” well)**  
   Playwright can attach a **per-context or per-test video** (often WebM). For proof runs you can:
   - turn recording on for a short scenario, or  
   - record only the steps you care about (open URL → trigger animation → wait → stop).  
   The output is a **small file** an agent (or you) can open, and vision-capable models can reason over **short** video much more sensibly than over dozens of unrelated snapshots.

2. **A dedicated “proof clip” script or MCP tool**  
   You could wrap the same idea in a **single command** or **MCP tool**, e.g. `record-browser-proof({ url, seconds: 5 })` that:
   - launches headful or headed browser (or uses the existing automation stack),
   - records **N seconds** after a trigger,
   - writes `proof-*.webm` to a known path (e.g. `artifacts/` or `.cursor/…`).  
   The agent’s job is then: **run the tool → point you at the file** (or attach it in chat if your Cursor workflow supports video attachments for that model).

3. **Browser automation “burst” (no true video)**  
   If you don’t want video files: **5–15 screenshots at 200–500 ms intervals** over 2–3 seconds often answers “did it scroll / animate?” This is easier on infra than encoding video, but it’s **not** one continuous motion sample — you said you prefer moving picture when snapshots aren’t enough; **short WebM is the right match**.

## What you’re not blocked on

- **Conceptually**: Short clips are the standard compromise between “static snapshot” and “live desktop.”
- **Technically**: Playwright + a few seconds of recording is **well supported**; wiring it into **your** proof workflow (npm script, CI artifact, or MCP) is mostly glue.

## Caveats (so expectations stay accurate)

- **Where the model “sees” the video** depends on **Cursor + model**: some chats accept **short video attachments** for vision models; other paths might only get **paths + your description** unless you attach the file yourself.
- **Encoding and size**: **WebM**, short duration, and modest resolution keep clips small and usable.

So: **you can make this happen** for agent-assisted browser proof by standardizing on **short Playwright recordings (or a thin wrapper/MCP)** as the “motion proof” artifact, used only when a snapshot isn’t enough — exactly the 1–10 second window you described. If you want to implement it in this repo next, say whether you prefer **npm script only**, **Playwright-only**, or **a small MCP server**, and we can align it with your existing `e2e/` setup.

---

**User**

I would prefer this to be something that We could build and be able to put on to the marketplace so that other people that are using cursor can also use it. So how can we make that happen? you

---

**Cursor**

Checking how Cursor distributes extensions and MCP integrations so we can give accurate, up-to-date guidance.



You can make this real for other Cursor users by shipping it as a **Cursor plugin** (the thing the [Cursor Marketplace](https://cursor.com/marketplace) installs), not only as a random script in one repo.

## How distribution works on Cursor’s side

Cursor’s model is: a **plugin bundles primitives** agents actually use:

- **MCP servers** — your “record 1–10s browser clip” logic lives here as tools (e.g. `start_recording`, `record_for_seconds`, `save_clip`).
- **Skills** (recommended) — short instructions so agents know *when* to prefer a short video over a snapshot, and what args to pass.
- Optionally **rules** / **hooks** if you want defaults or safety prompts.

Cursor documents this in their [plugins overview](https://cursor.com/docs/plugins) and accepts community submissions via **[Publish a plugin](https://cursor.com/marketplace/publish)** (linked from their [marketplace blog post](https://cursor.com/blog/marketplace)).

So the path to “others can install it” is: **build a plugin → submit to the marketplace** (plus open-source the repo so people can audit it).

## What you would actually build

**1. MCP server (the core product)**  
A small **Node (or Python) MCP server** that exposes a few tools, for example:

- `record_browser_clip` — `{ url?, durationSec (1–10), viewport?, outDir? }` → runs **Playwright** (or Puppeteer) with **video recording** enabled, performs optional steps (navigate, wait, scroll), writes **`*.webm`** to a known folder, returns **absolute path** (and maybe file size / duration).

Design choices that matter for marketplace users:

- **Dependencies**: Either document `npx playwright install` / browsers, or use a **bring-your-own-browser** story so your package isn’t enormous; many MCP servers assume a post-install step.
- **Security**: Clear scope — local only, user-triggered, writes to a user-chosen or project `artifacts/` folder, no silent exfiltration. Marketplace reviewers and users will care.
- **Cross-platform**: Windows/macOS/Linux paths and Playwright quirks.

**2. Skill file**  
A skill that says, in effect: *For motion, marquee, scroll, or transition validation, call `record_browser_clip` with N seconds; attach or open the resulting WebM; do not rely on a single snapshot.*

That’s what makes the capability **discoverable and correctly used** by agents, not just “a binary that exists.”

**3. Plugin manifest**  
Follow Cursor’s plugin packaging so the marketplace install wires the MCP server into users’ Cursor config automatically (exact format is in their **plugins docs** — you’ll mirror how existing marketplace plugins declare MCP + skills).

## Practical roadmap

| Step | Outcome |
|------|--------|
| 1. Prototype MCP + Playwright locally | One tool, 3–5s WebM, stable on your machine |
| 2. Add Skill + README | Agents and humans know when/how to use it |
| 3. Open-source repo + semver | Trust + issues + PRs |
| 4. Package as Cursor plugin + submit | Listed on marketplace for one-click install |

## Expectations

- **Marketplace curation**: Cursor started with partner-heavy listings and is **accepting submissions**; timeline and bar for approval are theirs, not something we control from code.
- **Parallel channel**: Even before or without listing, shipping **`npm` + `mcp.json` snippet** in README still helps everyone who doesn’t mind manual MCP setup.

So yes: **the realistic way to “put it on the marketplace” is an MCP-based Cursor plugin** (with a Skill) that records **short Playwright videos** and returns the file path. If you want to move from planning to implementation in your workspace next, we can sketch the exact tool schema and repo layout Cursor expects for plugins — say if you want **Node/TypeScript** or **Python** for the MCP server.

---

**User**

Just so you know, I have no technical understanding or background. I'm a vibe coder. So if you wanted me to be involved in the technical side, I will not be able to help. I will be of no use to you. but I would like to make this happen so that not only myself but others can use this feature. And deal with that. have much more than just a snapshot when they need it. So if you I truly believe you can make that happen and do it all, and it won't. be too much of a hassle to make it happen, then go ahead and make it happen, make the skill, make the tool or whatever they call it, the MCP. Create the plan and then make sure you double check the plan that is completely thorough, has everything you need so that you can get the job done from beginning to end and then Go ahead and make it.

---

**Cursor**

Researching Cursor's plugin packaging and MCP patterns so we can produce a complete, actionable plan. We're in plan mode — we'll create the plan for your approval, then implement after you confirm.



Having gathered Cursor’s official plugin layout, MCP bundling rules, and submission path, one open choice remains: whether to keep the plugin inside the DECYD repo or as a standalone repository (marketplace expects a public Git repo — often a dedicated repo). Planning a standalone plugin folder in the workspace that you can push as its own GitHub repository for submission.



---

**User**

i forgot to make a new projrect folder for us to do this. should i do that now so we dont mix this poroject with the DECYD project? or do you have a better solution?

---

**Cursor**

Recommending a separate folder and repo so we don't mix DECYD with the plugin. Updating the plan to make that the default.



Using a separate folder is the better approach. Updating the plan to make that the default location.



**Yes — use a new project folder outside DECYD.** That’s the better approach, and it’s what the plan now assumes.

**Why separate is better**

- **DECYD stays focused** on your app: no extra files, no mixed git history, no confusion in Cursor.
- **The plugin is its own product**: one public GitHub repo = one marketplace submission; reviewers and users see a clear, small project.
- **Simpler for you**: you only open the plugin folder when you care about that work.

**What you can do now (minimal)**

1. Create something like: `C:\Users\dadus\Desktop\Apps\cursor-browser-motion-plugin` (empty is fine).
2. When we implement, open **that** folder in Cursor (or use it as the workspace root for this work).

You do **not** have to run `git` from the command line if you use GitHub Desktop later; the important part is **physical separation** from DECYD.

The written plan is updated so the **default location is this sibling folder**, not inside DECYD. When you want the actual build (MCP + skill + files), say to **execute the plan** and we’ll target that new folder path.

