import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import * as z from "zod";
import { recordBrowserClip } from "./record.js";

const mcpServer = new McpServer({
  name: "browser-motion-proof",
  version: "1.0.0",
});

mcpServer.registerTool(
  "record_browser_clip",
  {
    description:
      "Open a URL in Chromium, record a short WebM (1–10s after page load) for motion/animation proof. Choose full viewport, a rectangular region in page coordinates, or a CSS element. Only http/https. Returns the absolute path to the video file.",
    inputSchema: {
      url: z
        .string()
        .describe("Page URL; must start with http:// or https://"),
      durationSeconds: z
        .number()
        .describe("Seconds to record after load; values are clamped between 1 and 10"),
      viewport: z
        .object({
          width: z.number().int().positive(),
          height: z.number().int().positive(),
        })
        .optional()
        .describe(
          "Initial browser viewport for load (default 1280x720). For focusMode viewport, this is the recorded frame. For region/element, used first for layout then viewport is resized to the focus area.",
        ),
      focusMode: z
        .enum(["viewport", "region", "element"])
        .optional()
        .describe(
          "viewport = record the whole browser view; region = record a rectangle in page coordinates; element = record around a CSS selector match",
        ),
      region: z
        .object({
          x: z.number(),
          y: z.number(),
          width: z.number().positive(),
          height: z.number().positive(),
        })
        .optional()
        .describe('Required when focusMode is "region": rectangle in page/document pixels'),
      selector: z
        .string()
        .optional()
        .describe('Required when focusMode is "element": CSS selector (first match)'),
      elementPadding: z
        .number()
        .min(0)
        .optional()
        .describe("Pixels of padding around the element box when focusMode is element; default 8"),
      headless: z
        .boolean()
        .optional()
        .describe("Run headless; default true (some sites behave differently when false)"),
    },
  },
  async ({
    url,
    durationSeconds,
    viewport,
    headless,
    focusMode,
    region,
    selector,
    elementPadding,
  }) => {
    try {
      const { videoPath, durationSeconds: used } = await recordBrowserClip({
        url,
        durationSeconds,
        viewport,
        headless,
        focusMode,
        region,
        selector,
        elementPadding,
      });
      const text = [
        "Recording complete.",
        "",
        `File (absolute path): ${videoPath}`,
        `Duration recorded: ${used}s`,
        "",
        "Open this .webm locally, or attach the file in chat so a vision-capable model can review motion and timing.",
      ].join("\n");
      return {
        content: [{ type: "text" as const, text }],
      };
    } catch (e) {
      const message = e instanceof Error ? e.message : String(e);
      return {
        content: [{ type: "text" as const, text: message }],
        isError: true,
      };
    }
  },
);

async function main() {
  const transport = new StdioServerTransport();
  await mcpServer.connect(transport);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
