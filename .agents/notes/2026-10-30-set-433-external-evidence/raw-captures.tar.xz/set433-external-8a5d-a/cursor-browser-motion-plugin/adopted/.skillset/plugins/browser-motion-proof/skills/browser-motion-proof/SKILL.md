---
name: browser-motion-proof
description: Record a short browser video (WebM) to verify motion, scrolling, marquees, or CSS animations. Use when a single page snapshot or screenshot is not enough—choose full page view, a specific on-page region, or one element via CSS selector.
skillset:
  origin:
    path: skills/browser-motion-proof/SKILL.md
---

# Browser motion proof

## When to use

- You need to see **movement** (scrolling, transitions, hover effects, marquees).
- A **static snapshot** cannot show what happens over time.
- The user asks to **verify animation**, **smooth scrolling**, or **UI that changes without navigation**.
- The user cares about **one part of the page** (a card, chart, hero, modal) rather than the entire window.

## Choosing what to record (`focusMode`)

Use **`record_browser_clip`** with the right **`focusMode`** so the video matches the question:

| Goal | Use | What to pass |
|------|-----|----------------|
| Whole browser view (default) | `focusMode: "viewport"` or omit | Optional **`viewport`** `{ width, height }` (default 1280×720). The recording is exactly that window. |
| A **rectangle** on the page (an “area”) | `focusMode: "region"` | **`region`**: `{ x, y, width, height }` in **page/document pixels** (from the top-left of the scrollable page, not the monitor). |
| One **DOM element** (button, section, canvas, etc.) | `focusMode: "element"` | **`selector`**: a CSS selector; first match is used. Optional **`elementPadding`** (pixels of margin around the box; default 8). |

**Workflow tips**

1. If the user names a **component** or **section**, prefer **`element`** with a stable selector (e.g. `[data-testid="…"]`, `#hero`, `.chart-root`) when you can infer or obtain it from markup or a prior snapshot.
2. If the user gives **coordinates** or describes a **crop box** (“the top 400px”, “the left column”), use **`region`** with explicit numbers. Coordinates are **page space**: scrolling changes what is visible, but `x`/`y` stay relative to the document origin.
3. For **full-page** layout, motion across the whole UI, or when no smaller target is specified, use **`viewport`** (or omit `focusMode`).

**Common inputs (always required)**

- **`url`**: `http://` or `https://` only.
- **`durationSeconds`**: 1–10 seconds of recording **after** the page has loaded and the focus has been applied.

**Optional**

- **`viewport`**: Initial window size for navigation. For `region` / `element`, the tool loads the page at this size, then **resizes the viewport** to the focused area so the WebM shows mostly that region.
- **`headless`**: default `true`; set `false` if a site behaves oddly headless.

4. When the tool returns, note the **absolute file path** to the `.webm`. Open it locally or **attach the video file in chat** so a vision-capable model can review it. **Attaching the file** is more reliable than assuming the client will ingest video automatically.

## One-time setup for the user

Browsers for Playwright are installed separately from Node. The plugin README explains running **`npx playwright install chromium`** once (from the `server` folder or after installing the server package). If recording fails with a “browser not found” style message, that step is usually missing.

## Safety

The tool loads **real URLs** in a real browser. Use only on **trusted** sites (including local dev servers). Avoid untrusted or unknown URLs.
