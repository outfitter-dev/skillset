import { existsSync, statSync } from "node:fs";
import { recordBrowserClip } from "./record.js";

function assertWebm(path: string, label: string): void {
  if (!path.endsWith(".webm")) {
    console.error(`${label}: expected .webm, got:`, path);
    process.exit(1);
  }
  if (!existsSync(path)) {
    console.error(`${label}: file missing:`, path);
    process.exit(1);
  }
  const st = statSync(path);
  if (st.size < 100) {
    console.error(`${label}: file too small:`, st.size, path);
    process.exit(1);
  }
  console.error(`${label} OK:`, path, `(${st.size} bytes)`);
}

async function main() {
  const a = await recordBrowserClip({
    url: "https://example.com",
    durationSeconds: 2,
    headless: true,
  });
  assertWebm(a.videoPath, "Smoke viewport");

  const b = await recordBrowserClip({
    url: "https://example.com",
    durationSeconds: 1,
    headless: true,
    focusMode: "element",
    selector: "h1",
  });
  assertWebm(b.videoPath, "Smoke element");

  const c = await recordBrowserClip({
    url: "https://example.com",
    durationSeconds: 1,
    headless: true,
    focusMode: "region",
    region: { x: 0, y: 0, width: 400, height: 200 },
  });
  assertWebm(c.videoPath, "Smoke region");
}

main().catch((e) => {
  console.error("Smoke failed:", e);
  process.exit(1);
});
